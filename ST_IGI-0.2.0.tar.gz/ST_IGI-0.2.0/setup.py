from setuptools import setup, find_packages

__version__ = "0.2.0"

setup(
    name="ST_IGI",
    python_requires = ">=3.9",
    version=__version__,
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    include_package_data=True,
    install_requires=[
    'torch@https://download.pytorch.org/whl/cu102/torch-1.11.0%2Bcu102-cp39-cp39-linux_x86_64.whl',
    'torchvision@https://download.pytorch.org/whl/cu102/torchvision-0.12.0%2Bcu102-cp39-cp39-linux_x86_64.whl',
    'torch-cluster@https://data.pyg.org/whl/torch-1.11.0%2Bcu102/torch_cluster-1.6.0-cp39-cp39-linux_x86_64.whl',
    'torch-scatter@https://data.pyg.org/whl/torch-1.11.0%2Bcu102/torch_scatter-2.0.9-cp39-cp39-linux_x86_64.whl',
    'torch-sparse@https://data.pyg.org/whl/torch-1.11.0%2Bcu102/torch_sparse-0.6.15-cp39-cp39-linux_x86_64.whl',
    'torch-geometric@https://files.pythonhosted.org/packages/bd/e3/3913bc65cb23db1dcc5a69a87f53206ebcdfebc28973535a4a64a0cb97cd/torch_geometric-2.1.0.post1.tar.gz',
    'matplotlib',
    'pandas',
    'palettable',
    'opencv-python'
    ],
    author="Ruitian Gao",
    author_email="r.t.gao@sjtu.edu.cn",
    keywords=["spatial transcriptomics", "geometric deep learning", "histological images"],
    description="an integrated graph and image deep learning (IGI-DL) model for gene spatial expression prediction based on HE slides of cancer",
    license="MIT",
    url='',
)

