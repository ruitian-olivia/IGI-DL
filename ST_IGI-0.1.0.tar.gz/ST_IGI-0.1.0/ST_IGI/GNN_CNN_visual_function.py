import os
import cv2
import json
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.cm as cm
from matplotlib import pyplot as plt
from palettable.colorbrewer.diverging import RdYlBu_10_r

def spatial_visual_function(predict_data, test_result_df, test_corr, target_gene, spatial_type = "10X"):
    label_sr = test_result_df["label"]
    l_q1 = label_sr.quantile(0.25)
    l_q3 = label_sr.quantile(0.75)
    l_iqr = l_q3-l_q1 
    l_fence_low  = l_q1-2*l_iqr
    l_fence_high = l_q3+2*l_iqr
    l_minima = max(l_fence_low, min(list(test_result_df["label"])))
    l_maxima = min(l_fence_high, max(list(test_result_df["label"])))
    l_norm = matplotlib.colors.Normalize(vmin=l_minima, vmax=l_maxima, clip=True)
    l_mapper = cm.ScalarMappable(norm=l_norm, cmap=RdYlBu_10_r.mpl_colormap)
    
    pred_sr = test_result_df["pred"]
    q1 = pred_sr.quantile(0.25)
    q3 = pred_sr.quantile(0.75)
    iqr = q3-q1 
    fence_low  = q1-2*iqr
    fence_high = q3+2*iqr
    p_minima = max(fence_low, min(list(test_result_df["pred"])))
    p_maxima = min(fence_high,max(list(test_result_df["pred"])))
    p_norm = matplotlib.colors.Normalize(vmin=p_minima, vmax=p_maxima, clip=True)
    p_mapper = cm.ScalarMappable(norm=p_norm, cmap=RdYlBu_10_r.mpl_colormap)

    img_rgb = predict_data.img_rgb
    img_shape = img_rgb.shape
    
    spot_radius = predict_data.spot_radius

    l_heatmap_array = np.ones(img_shape,dtype=np.uint8) * 255
    p_heatmap_array = np.ones(img_shape,dtype=np.uint8) * 255
    mask_array = np.zeros(img_shape[:2],dtype=np.uint8)

    for _,row in test_result_df.iterrows():
        x_coor = int(row['x_coor'])
        y_coor = int(row['y_coor'])
        l_feature = row['label']
        p_feature = row['pred']
        l_mapped_rgb = l_mapper.to_rgba(l_feature, alpha=None, bytes=True, norm=True)
        p_mapped_rgb = p_mapper.to_rgba(p_feature, alpha=None, bytes=True, norm=True)
        if spatial_type == "10X":    
            cv2.circle(l_heatmap_array,(y_coor,x_coor),spot_radius,(int(l_mapped_rgb[0]), int(l_mapped_rgb[1]), int(l_mapped_rgb[2])),-1)
            cv2.circle(p_heatmap_array,(y_coor,x_coor),spot_radius,(int(p_mapped_rgb[0]), int(p_mapped_rgb[1]), int(p_mapped_rgb[2])),-1)
            cv2.circle(mask_array,(y_coor,x_coor),spot_radius,255,-1)
        elif spatial_type == "ST":
            cv2.circle(l_heatmap_array,(x_coor,y_coor),spot_radius,(int(l_mapped_rgb[0]), int(l_mapped_rgb[1]), int(l_mapped_rgb[2])),-1)
            cv2.circle(p_heatmap_array,(x_coor,y_coor),spot_radius,(int(p_mapped_rgb[0]), int(p_mapped_rgb[1]), int(p_mapped_rgb[2])),-1)
            cv2.circle(mask_array,(x_coor,y_coor),spot_radius,255,-1)
        else:
            raise ValueError(f"no spatial_type named {spatial_type}!")
        
    mask_inv = cv2.bitwise_not(mask_array)
    img_bg = cv2.bitwise_and(img_rgb,img_rgb,mask = mask_inv)
    l_img_fg = cv2.bitwise_and(l_heatmap_array,l_heatmap_array,mask = mask_array)
    p_img_fg = cv2.bitwise_and(p_heatmap_array,p_heatmap_array,mask = mask_array)
    l_out_img = cv2.add(img_bg,l_img_fg)
    p_out_img = cv2.add(img_bg,p_img_fg)

    fig = plt.figure(dpi=300,figsize=(15,8),facecolor='white')
    ax = fig.add_subplot(121)
    ax.set_title('True %s spatial expression' % (target_gene))
    l_img = plt.imshow(l_out_img)
    plt.axis('off')
    bx = fig.add_subplot(122)
    bx.set_title('Predicted %s  (Correlation: %.3f)' % (target_gene, test_corr))
    p_img = plt.imshow(p_out_img, cmap=RdYlBu_10_r.mpl_colormap)
    plt.axis('off')
    cb1 = fig.colorbar(p_img, ax=[ax, bx], shrink=0.6)
    cb1.set_ticks([])
    
    return fig
