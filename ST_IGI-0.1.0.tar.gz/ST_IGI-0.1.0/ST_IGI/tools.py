import os
import io
import cv2
import gzip
import json
import torch
import pickle
import zipfile
import requests
import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from torch_geometric.loader import DataLoader
from scipy.spatial.distance import pdist, squareform

from .GNN_CNN_fusion_model import GIN4layer_ResNet18
from .GNN_CNN_visual_function import spatial_visual_function

class data:
    def __init__(self, data_type='cSCC'):
        types = ('cSCC', 'breast_cancer')
        if data_type not in types:
            raise ValueError(f"Invalid data type: {cancer_type}. Must be one of {types}")
        self.data_type = data_type
        
        local_path = './download_data'
        
        if not os.path.exists(local_path):
            os.makedirs(local_path)
        
        if data_type == "cSCC":
            data_path = os.path.join(local_path, 'cSCC/V10F24-015_A1')
            if not os.path.exists(data_path):
                url = 'https://zenodo.org/record/7937635/files/cSCC.zip?download=1'
                response = requests.get(url)
                zip_file = zipfile.ZipFile(io.BytesIO(response.content))
                zip_file.extractall(local_path)
            
            graph_path = os.path.join(data_path, 'graph_image_pt.pklz')
            data_gene_path = os.path.join(data_path, 'target_gene_list.txt')
            hires_img_path = os.path.join(data_path, 'tissue_hires_image.png')
            scalefactor_file_path = os.path.join(data_path, 'scalefactors_json.json')
            
            hires_img = cv2.imread(hires_img_path,1)
            img_rgb = cv2.cvtColor(hires_img, cv2.COLOR_BGR2RGB)
            
            with open(scalefactor_file_path, 'r', encoding = 'utf-8') as f:
                scalefactor_dict = json.load(f)
            fullres = scalefactor_dict['spot_diameter_fullres']
            scalef = scalefactor_dict['tissue_hires_scalef']
            spot_radius = round(fullres*scalef/2)
                 
        elif data_type == "breast_cancer":
            data_path = os.path.join(local_path, 'breast_cancer/invasive_ductal_Layer4')
            if not os.path.exists(data_path):
                url = 'https://zenodo.org/record/7937635/files/breast_cancer.zip?download=1'
                response = requests.get(url)
                zip_file = zipfile.ZipFile(io.BytesIO(response.content))
                zip_file.extractall(local_path)
            
            graph_path = os.path.join(data_path,'graph_image_pt.pklz')
            data_gene_path = os.path.join(data_path,'target_gene_list.txt')
            tissue_img_path = os.path.join(data_path,"HE_layer4_BC.jpg")
            coord_file_path = os.path.join(data_path,"coord.csv")
            
            tissue_img = cv2.imread(tissue_img_path,1)
            img_rgb = cv2.cvtColor(tissue_img, cv2.COLOR_BGR2RGB)
            
            coord_df = pd.read_csv(coord_file_path, index_col="barcode")
            coords_np = np.array(coord_df[['pixel_x', 'pixel_y']])
            coords_list = [tuple(x) for x in coords_np.tolist()]
            distance = squareform(pdist(coords_list))
            distance[distance == 0] = np.nan
            neighbor_distance = np.nanmin(distance)
            spot_radius = round(neighbor_distance/4)
    
        with gzip.open(graph_path, 'rb') as f:
            graph_tissue_list = pickle.load(f)
        self.graph_loader = DataLoader(graph_tissue_list, batch_size=128, shuffle = False)
        
        with open(data_gene_path, "r", encoding="utf-8") as f:
            self.data_gene_list = f.read().splitlines()
            
        self.img_rgb = img_rgb
        self.spot_radius = spot_radius

class model:
    def __init__(self, cancer_type='cSCC'):
        types = ('cSCC', 'breast_cancer', 'CRC')
        if cancer_type not in types:
            raise ValueError(f"Invalid cancer type: {cancer_type}. Must be one of {types}")
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        self.cancer_type = cancer_type
                            
        if cancer_type == 'cSCC':
            self.weight_root = './model_weights/cSCC'
            self.weights = os.path.join(self.weight_root,'IGI-DL-cSCC-weights.pth')
            self.weights_url = 'https://github.com/ruitian-olivia/IGI-DL/raw/master/model_weights/cSCC/IGI-DL-cSCC-weights.pth'
            self.gene_path = os.path.join(self.weight_root,'cSCC_gene_list.txt')
            self.gene_path_url = 'https://github.com/ruitian-olivia/IGI-DL/raw/master/model_weights/cSCC/cSCC_gene_list.txt'
            
        elif cancer_type == 'breast_cancer':
            self.weight_root = './model_weights/breast_cancer'
            self.weights = os.path.join(self.weight_root,'IGI-DL-breast-weights.pth')
            self.weights_url = 'https://github.com/ruitian-olivia/IGI-DL/raw/master/model_weights/breast_cancer/IGI-DL-breast-weights.pth'
            self.gene_path = os.path.join(self.weight_root,'breast_gene_list.txt')
            self.gene_path_url = 'https://github.com/ruitian-olivia/IGI-DL/raw/master/model_weights/breast_cancer/breast_gene_list.txt'
        
        else:
            self.weight_root = './model_weights/CRC'
            self.weights = os.path.join(self.weight_root,'IGI-DL-CRC-weights.pth')
            self.weights_url = 'https://github.com/ruitian-olivia/IGI-DL/raw/master/model_weights/CRC/IGI-DL-CRC-weights.pth'
            self.gene_path = os.path.join(self.weight_root,'CRC_gene_list.txt')
            self.gene_path_url = 'https://github.com/ruitian-olivia/IGI-DL/raw/master/model_weights/CRC/CRC_gene_list.txt'
        print("os.path.exists(self.weight_root):", os.path.exists(self.weight_root))
        if  os.path.exists(self.weight_root):
            print("self.weight_root:", self.weight_root)
            
        if not os.path.exists(self.weight_root):
            print("Create new directory!")
            os.makedirs(self.weight_root)
            
        if not os.path.exists(self.weights):
            response = requests.get(self.weights_url)
            with open(self.weights, "wb") as file:
                file.write(response.content)
                
        if not os.path.exists(self.gene_path):
            response = requests.get(self.gene_path_url)
            with open(self.gene_path, "wb") as file:
                file.write(response.content)
        
        with open(self.gene_path, "r", encoding="utf-8") as f:
            self.model_gene_list = f.read().splitlines()
            self.num_gene = len(self.model_gene_list)
            
        self.model = GIN4layer_ResNet18(85, self.num_gene, 256, [512, 256, 256]).to(self.device)
        self.model.load_state_dict(torch.load(self.weights, map_location = torch.device(self.device)))
    
    def predict_expression(self, predict_data):
        
        self.predict_data = predict_data
        graph_loader = self.predict_data.graph_loader
        
        self.model.eval()
        gene_predict_record = None
        
        for data in graph_loader:
            if 'y' in data.__dict__['_store']:
                label_flag = True
            else:
                label_flag = False
            break
        
        for data in graph_loader:
            data = data.to(self.device)
            gene_output = self.model(data)
                    
            _tmp_gene = gene_output.cpu().detach().numpy()
            if label_flag:
                _tmp_label = data.y.cpu().detach().numpy()
            _tmp_x_coord = data.x_coor.cpu().detach().numpy()
            _tmp_y_coord = data.y_coor.cpu().detach().numpy()
            
            if gene_predict_record is None:
                gene_predict_record = _tmp_gene
                if label_flag:
                    label_record = _tmp_label
                x_coord_record = _tmp_x_coord
                y_coord_record = _tmp_y_coord
            else:
                gene_predict_record = np.vstack([gene_predict_record, _tmp_gene])
                if label_flag:
                    label_record = np.vstack([label_record, _tmp_label])
                x_coord_record = np.hstack([x_coord_record, _tmp_x_coord])
                y_coord_record = np.hstack([y_coord_record, _tmp_y_coord])
        
        self.gene_expression_np = gene_predict_record
        if label_flag:
            self.label_np = label_record
        self.x_coord_np = x_coord_record
        self.y_coord_np = y_coord_record
            
    def cal_gene_corr(self):
        pear_corr_list = []
        pear_log_p_list = []
        
        data_gene_list = self.predict_data.data_gene_list
        
        for gene_name in data_gene_list:
            model_gene_idx = self.model_gene_list.index(gene_name)
            label_gene_idx = data_gene_list.index(gene_name)
                
            label_gene = self.label_np[:,label_gene_idx]
            pred_gene = self.gene_expression_np[:,model_gene_idx]
        
            pear_corr, pear_p = pearsonr(label_gene, pred_gene)
            pear_log_p = -np.log10(pear_p+1e-10)
            
            pear_corr_list.append(pear_corr)
            pear_log_p_list.append(pear_log_p)
            
        result_dict = {"Pear_corr" : pear_corr_list,
                    "Pear_log_p" : pear_log_p_list
                    }
        result_df = pd.DataFrame(result_dict)
        result_df.index = data_gene_list
        
        result_df.sort_values(by="Pear_corr", inplace=True, ascending=False)
        self.result_df = result_df
        
        return result_df
    
    def spatial_visual(self, target_gene, spatial_type="10X"):
        target_pear_corr = self.result_df.loc[target_gene, "Pear_corr"]
        
        model_gene_idx = self.model_gene_list.index(target_gene)
        label_gene_idx = self.predict_data.data_gene_list.index(target_gene)
        
        test_result_dict = {
            "label":self.label_np[:, label_gene_idx],
            "pred":self.gene_expression_np[:, model_gene_idx],
            "x_coor":self.x_coord_np,
            "y_coor":self.y_coord_np,
        } 
        
        test_result_df = pd.DataFrame(test_result_dict)
        visual_fig = spatial_visual_function(self.predict_data, test_result_df, target_pear_corr, target_gene, spatial_type)
            
        return visual_fig
 